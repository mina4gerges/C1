package com.yaps.petstore;

/**
 * This exception is thrown when a Customer is not found in the hashmap.
 */
public final class CustomerNotFoundException extends CustomerFinderException {
}
