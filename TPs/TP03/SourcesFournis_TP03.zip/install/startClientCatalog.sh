../clientCatalog/build/install/clientCatalog/bin/clientCatalog
 
