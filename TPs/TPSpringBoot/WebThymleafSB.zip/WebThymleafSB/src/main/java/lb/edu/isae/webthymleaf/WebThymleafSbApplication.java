package lb.edu.isae.webthymleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebThymleafSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebThymleafSbApplication.class, args);
	}

}
