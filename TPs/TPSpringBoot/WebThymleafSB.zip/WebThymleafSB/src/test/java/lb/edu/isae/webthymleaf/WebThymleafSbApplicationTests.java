package lb.edu.isae.webthymleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebThymleafSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
